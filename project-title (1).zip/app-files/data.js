var APP_DATA = {
  "scenes": [
    {
      "id": "0-gs__0575",
      "name": "GS__0575",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.6411721610261623,
          "pitch": -0.22863644185592946,
          "rotation": 0,
          "target": "1-gs__0576"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 2.1839729493657156,
          "pitch": -0.1687277307862587,
          "title": "ห้องชมรมโฟโต้",
          "text": "Text"
        },
        {
          "yaw": 0.34659195704506374,
          "pitch": -0.2721609978015316,
          "title": "ห้องชมรมForester",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-gs__0576",
      "name": "GS__0576",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.5162937980129136,
          "pitch": -0.13957298223603232,
          "rotation": 0,
          "target": "0-gs__0575"
        },
        {
          "yaw": -1.1492275462332167,
          "pitch": -0.16072770103760448,
          "rotation": 0,
          "target": "2-gs__0577"
        },
        {
          "yaw": 0.8576112022904123,
          "pitch": -0.03306812405280546,
          "rotation": 0,
          "target": "3-gs__0578"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 3.008468433857976,
          "pitch": -0.34201109734299706,
          "title": "ห้องชมรมForester",
          "text": "Text"
        }
      ]
    },
    {
      "id": "2-gs__0577",
      "name": "GS__0577",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.2639335279479944,
          "pitch": -0.22632463706560912,
          "rotation": 0,
          "target": "1-gs__0576"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 2.0998743179114996,
          "pitch": -0.2952926636715354,
          "title": "ห้องชมรมNusery",
          "text": "Text"
        },
        {
          "yaw": -2.2604811413894694,
          "pitch": -0.36397273881410896,
          "title": "ห้องน้ำชาย",
          "text": "Text"
        },
        {
          "yaw": -2.0348601135548012,
          "pitch": -0.3343369925753521,
          "title": "ห้องน้ำหญิง",
          "text": "Text"
        }
      ]
    },
    {
      "id": "3-gs__0578",
      "name": "GS__0578",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.5958167978954965,
          "pitch": -0.005069287306749715,
          "rotation": 0,
          "target": "4-gs__0579"
        },
        {
          "yaw": -3.0593580712271446,
          "pitch": 0.047379063288715884,
          "rotation": 0,
          "target": "1-gs__0576"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.06089234165305868,
          "pitch": -0.31949067733472525,
          "title": "ห้องประชุมอเนกประสงค์",
          "text": "Text"
        }
      ]
    },
    {
      "id": "4-gs__0579",
      "name": "GS__0579",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.596578535545145,
          "pitch": -0.024131319329136147,
          "rotation": 0,
          "target": "3-gs__0578"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.6000760620758854,
          "pitch": -0.3254971164137075,
          "title": "ห้องเก็บของ",
          "text": "Text"
        },
        {
          "yaw": 3.108783438572816,
          "pitch": -0.28771925943462584,
          "title": "ห้องน้ำชาย",
          "text": "Text"
        },
        {
          "yaw": -2.9468300835799326,
          "pitch": -0.19708932133894308,
          "title": "ห้องน้ำหญิง",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
